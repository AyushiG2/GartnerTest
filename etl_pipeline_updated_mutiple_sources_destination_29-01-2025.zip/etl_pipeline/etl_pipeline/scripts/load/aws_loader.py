import boto3
import os
import logging
from config.config import aws

def load_to_s3(transformed_dir):
    s3 = boto3.client('s3', region_name=aws['region'])
    bucket_name = aws['s3_bucket']
    s3_prefix = aws.get('s3_prefix', 'processed/')  # Optional S3 prefix/folder

    for file in os.listdir(transformed_dir):
        file_path = os.path.join(transformed_dir, file)
        s3_key = f"{s3_prefix}{file}"

        try:
            s3.upload_file(file_path, bucket_name, s3_key)
            logging.info(f"Uploaded {file} to s3://{bucket_name}/{s3_key}")
        except Exception as e:
            logging.error(f"Error uploading {file} to S3: {str(e)}")

    return f"s3://{bucket_name}/{s3_prefix}"
