import psycopg2
import logging
from config.config import database


def load_to_database(transformed_dir):
    conn = psycopg2.connect(
        host=database['host'],
        port=database['port'],
        user=database['user'],
        password=database['password'],
        dbname=database['dbname']
    )
    cursor = conn.cursor()

    for file in os.listdir(transformed_dir):
        file_path = os.path.join(transformed_dir, file)
        with open(file_path, 'r') as f:
            next(f)  # Skip header
            cursor.copy_expert(f"COPY my_table FROM STDIN WITH CSV HEADER", f)
            conn.commit()
        logging.info(f"Loaded {file} into database")

    cursor.close()
    conn.close()
