import pandas as pd
import os
import logging


def transform_data(raw_data_dir):
    transformed_dir = "data/transformed/"
    os.makedirs(transformed_dir, exist_ok=True)

    for file in os.listdir(raw_data_dir):
        raw_file_path = os.path.join(raw_data_dir, file)
        transformed_file_path = os.path.join(transformed_dir, file)

        # Example transformation
        df = pd.read_csv(raw_file_path)
        df = df.dropna()  # Drop rows with missing values
        df.to_csv(transformed_file_path, index=False)
        logging.info(f"Transformed {file} and saved to {transformed_file_path}")

    return transformed_dir
