import paramiko
import os
import logging
from config.config import sftp

def extract_from_sftp():
    host = sftp['host']
    port = sftp.get('port', 22)
    username = sftp['username']
    password = sftp['password']
    remote_dir = sftp['remote_dir']
    local_dir = "data/raw/"

    os.makedirs(local_dir, exist_ok=True)

    try:
        transport = paramiko.Transport((host, port))
        transport.connect(username=username, password=password)
        sftp_client = paramiko.SFTPClient.from_transport(transport)

        for file_attr in sftp_client.listdir_attr(remote_dir):
            remote_file = f"{remote_dir}/{file_attr.filename}"
            local_file = os.path.join(local_dir, file_attr.filename)
            sftp_client.get(remote_file, local_file)
            logging.info(f"Downloaded {file_attr.filename} to {local_file}")

        sftp_client.close()
        transport.close()
    except Exception as e:
        logging.error(f"Error extracting from SFTP: {str(e)}")

    return local_dir
