import psycopg2
import pandas as pd
import os
import logging
from config.config import db

def extract_from_db():
    conn_params = {
        "dbname": db['dbname'],
        "user": db['user'],
        "password": db['password'],
        "host": db['host'],
        "port": db.get('port', 5432)
    }

    query = db['query']
    output_dir = "data/raw/"
    output_file = os.path.join(output_dir, "db_extract.csv")

    os.makedirs(output_dir, exist_ok=True)

    try:
        conn = psycopg2.connect(**conn_params)
        df = pd.read_sql(query, conn)
        df.to_csv(output_file, index=False)
        logging.info(f"Extracted data from DB and saved to {output_file}")

        conn.close()
    except Exception as e:
        logging.error(f"Error extracting from DB: {str(e)}")

    return output_file
