Prerequisites

Python 3.8+

pip install -r requirements.txt

AWS CLI configured with appropriate permissions

PostgreSQL or compatible database

Installation

Clone the repository:

Run the ETL pipeline: python main.py