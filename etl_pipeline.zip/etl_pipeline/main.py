import logging
from scripts.extract.s3_extractor import extract_from_s3
from scripts.transform.data_transformer import transform_data
from scripts.load.db_loader import load_to_database
from config.logging_config import setup_logging

# Setup logging
setup_logging()


def main():
    try:
        logging.info("Starting ETL pipeline...")

        # Extract phase
        logging.info("Extracting data...")
        raw_data = extract_from_s3()

        # Transform phase
        logging.info("Transforming data...")
        transformed_data = transform_data(raw_data)

        # Load phase
        logging.info("Loading data...")
        load_to_database(transformed_data)

        logging.info("ETL pipeline completed successfully!")
    except Exception as e:
        logging.error(f"ETL pipeline failed: {e}", exc_info=True)


if __name__ == "__main__":
    main()
