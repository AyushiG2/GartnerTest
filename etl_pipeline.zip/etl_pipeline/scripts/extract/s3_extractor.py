import boto3
import os
import logging
from config.config import aws


def extract_from_s3():
    s3 = boto3.client('s3', region_name=aws['region'])
    bucket_name = aws['s3_bucket']
    raw_data_dir = "data/raw/"

    os.makedirs(raw_data_dir, exist_ok=True)
    for obj in s3.list_objects(Bucket=bucket_name)['Contents']:
        file_name = obj['Key']
        local_path = os.path.join(raw_data_dir, file_name)
        s3.download_file(bucket_name, file_name, local_path)
        logging.info(f"Downloaded {file_name} to {local_path}")

    return raw_data_dir
